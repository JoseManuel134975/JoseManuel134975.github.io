<?php

namespace App\Controller;

use App\Entity\Post;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class ApiController extends AbstractController
{
    #[Route('/public/posts', name: 'app_api_posts')]
    public function posts(EntityManagerInterface $em, Request $request): JsonResponse
    {
        # leemos todos los artículos de la base de datos
        $posts = $em->getRepository(Post::class)->findAll();

        # Creamos un array vacío
        $arrayPosts = [];

        # Recorremos el array
        foreach ($posts as $p) {
            # Creamos otro array con los datos del artículo
            $tupla = ['id' => $p->getId(), 'userId' => $p->getUser(), 'content' => $p->getContent(), 'createdAt' => $p->getCreatedAt(), 'image' => $p->getImage(), 'day' => $p->getDay(), 'likes' => $p->getLikes()];
            # Lo añadimos al primer array
            array_push($arrayPosts, $tupla);
        }

        # Conbvertimos el array de arrays en un json
        return new JsonResponse(['posts' => $arrayPosts], JsonResponse::HTTP_OK);
    }

    #[Route('/api/posts/by/day', name: 'app_api_jsonpostsbyday', methods: ['GET', 'POST'])]
    public function postsByDay(EntityManagerInterface $em, Request $request, Security $security): JsonResponse
    {
        # Extraemos el cliente a partir de la decodificación del token
        $client = $security->getUser();

        /**
         * Params: $field (string), $day (string), $userId (int)
         * Consigo los posts de un día concreto dependiendo del id que le pase
         */
        $posts = $em->getRepository(Post::class)->findByDay('day', "04", $client->getId());
        $data = array_map(function ($post) {
            return
                [
                    'id' => $post->getId(),
                    'fecha' => $post->getCreatedAt()
                ];
        }, $posts);

        return new JsonResponse($data);
    }
}
