<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use App\Entity\Post;
use App\Entity\Replie;
use App\Entity\User;
use App\Form\PostByDayType;
use App\Form\PostType;
use App\Form\ReplieType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use DateTimeImmutable;
use Symfony\Component\String\Slugger\SluggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\Exception\FileException;



class MyWallController extends AbstractController
{
    #[Route('/my/wall', name: 'app_my_wall')]
    public function index(
        EntityManagerInterface $em,
        Request $request,
        SluggerInterface $slugger,
        #[Autowire('%kernel.project_dir%/public/postUploads/')] string $postBrochuresDirectory
    ): Response {
        $post = new Post();
        $postForm = $this->createForm(PostType::class, $post);
        $postsByDay = [];
        $postByDayForm = $this->createForm(PostByDayType::class);
        $postByDayForm->handleRequest($request);
        $postForm->handleRequest($request);

        if ($postByDayForm->isSubmitted() && $postByDayForm->isValid()) {
            $day = $postByDayForm->get('day')->getData()->format('d');
            $postsByDay = $this->getPostsByDay($em, $day, $this->getUser());
        }

        if ($postForm->isSubmitted() && $postForm->isValid()) {
            $postContent = $postForm->get('content')->getData();
            $postCreatedAt = new DateTimeImmutable("now");
            $day = $postCreatedAt->format('d');
            $postUserId = $this->getUser();
            $postBrochureFile = $postForm->get('brochure')->getData();
            $postLikes = -1;

            if ($postBrochureFile) {
                $postOriginalFileName = pathInfo($postBrochureFile->getClientOriginalName(), PATHINFO_FILENAME);
                $postSafeFileName = $slugger->slug($postOriginalFileName);
                $newFileName = $postSafeFileName . '-' . uniqid() . '.' . $postBrochureFile->guessExtension();

                try {
                    $postBrochureFile->move($postBrochuresDirectory . $this->getUser()->getUsername(), $newFileName);
                    $postPublicPath = '/postUploads' . '/' . $this->getUser()->getUsername() . '/' . $newFileName;
                    $post->setImage($postPublicPath);
                } catch (FileException $e) {
                    dd('An error happened when you tried upload the file: ' . $e);
                }
            }

            $post->setContent($postContent);
            $post->setCreatedAt($postCreatedAt);
            $post->setUser($postUserId);
            $post->setDay($day);
            $post->setLikes($postLikes);

            $em->persist($post);
            $em->flush();

            return $this->redirectToRoute('app_my_wall');
        }

        $users = $this->getUsers($em);
        $posts = $em->getRepository(Post::class)->orderByDate('user', $this->getUser());
        $replies = $em->getRepository(Replie::class)->findAll();

        foreach ($replies as $replie) {
            $postR = $em->getRepository(Post::class)->find($replie->getPost());
            $replie->setPost($postR);
            $postR->addReply($replie);
        }

        return $this->render('my_wall/index.html.twig', [
            'postForm' => $postForm,
            'posts' => $posts,
            'users' => $users,
            'postByDayForm' => $postByDayForm,
            'postsByDay' => $postsByDay
        ]);
    }

    #[Route('/my/wall/users', name: 'app_users')]
    public function showUsers(EntityManagerInterface $em, Request $request): Response
    {
        $users = $em->getRepository(User::class)->findAll();

        return $this->render('my_wall/users.html.twig', [
            'users' => $users,
        ]);
    }

    #[Route('/my/wall/{id}', name: 'app_other_wall')]
    public function changeWall(EntityManagerInterface $em, Request $request, User $user): Response
    {
        $postsByDay = [];
        $postByDayForm = $this->createForm(PostByDayType::class);
        $postByDayForm->handleRequest($request);
        $users = $this->getUsers($em);
        $posts = $em->getRepository(Post::class)->orderByDate('user', $user->getId());

        if ($postByDayForm->isSubmitted() && $postByDayForm->isValid()) {
            $day = $postByDayForm->get('day')->getData()->format('d');
            $postsByDay = $this->getPostsByDay($em, $day, $user);
        }

        return $this->render('my_wall/other_wall.html.twig', [
            'users' => $users,
            'posts' => $posts,
            'wallOwner' => $user,
            'postsByDay' => $postsByDay,
            'postByDayForm' => $postByDayForm
        ]);
    }

    #[Route('/my/wall/replie/{id}/{user}', name: 'app_replie')]
    public function repliePublic(
        EntityManagerInterface $em,
        Request $request,
        User $user,
        Post $post,
        SluggerInterface $slugger,
        #[Autowire('%kernel.project_dir%/public/postUploads/')] string $replieBrochuresDirectory
    ): Response {
        $replie = new Replie();
        $replieForm = $this->createForm(ReplieType::class, $replie);
        $replieForm->handleRequest($request);

        if ($replieForm->isSubmitted() && $replieForm->isValid()) {
            $answer = $replieForm->get('answer')->getData();
            $createdAt = new DateTimeImmutable("now");
            $userId = $this->getUser();
            $postId = $post;
            $replieBrochureFile = $replieForm->get('brochure')->getData();

            if ($replieBrochureFile) {
                $replieOriginalFileName = pathInfo($replieBrochureFile->getClientOriginalName(), PATHINFO_FILENAME);
                $replieSafeFileName = $slugger->slug($replieOriginalFileName);
                $newFileName = $replieSafeFileName . '-' . uniqid() . '.' . $replieBrochureFile->guessExtension();

                try {
                    $replieBrochureFile->move($replieBrochuresDirectory . $user->getUsername() . '/' . 'replies' . '/', $newFileName);
                    $repliePublicPath = '/postUploads' . '/' . $user->getUsername() . '/' . 'replies' . '/' . $newFileName;
                    $replie->setImage($repliePublicPath);
                } catch (FileException $e) {
                    dd('An error happened when you tried upload the file: ' . $e);
                }
            }

            $replie->setAnswer($answer);
            $replie->setCreatedAt($createdAt);
            $replie->setUser($userId);
            $replie->setPost($postId);
            $post->addReply($replie);

            $em->persist($replie);
            $em->flush();

            $this->addFlash('reply', 'El mensaje fue enviado correctamente :)');

            return $this->redirectToRoute('app_my_wall');
        }

        $users = $this->getUsers($em);

        return $this->render('my_wall/replie.html.twig', [
            'replieForm' => $replieForm,
            'users' => $users
        ]);
    }

    #[Route('/my/wall/delete/{id}', name: 'app_delete_post')]
    public function deletePost(EntityManagerInterface $em, Post $post): Response
    {
        $replies = $em->getRepository(Replie::class)->findAll();

        foreach ($replies as $replie) {
            $postR = $em->getRepository(Post::class)->find($replie->getPost());
            $replie->setPost($postR);
            if ($post->getId() == $replie->getPost()->getId()) {
                $post->addReply($replie);
                $post->removeReply($replie);
                $em->remove($replie);
            }
        }

        $em->remove($post);
        $em->flush();

        return $this->redirectToRoute('app_my_wall');
    }

    #[Route('/my/wall/like/{id}', name: 'app_give_like')]
    public function giveLike(EntityManagerInterface $em, Post $post): Response
    {
        $post->setLikes($post->getLikes());
        $em->persist($post);
        $em->flush();

        $this->addFlash('like', 'El me gusta fue recibido correctamente :)');

        return $this->redirectToRoute('app_my_wall');
    }

    public function getUsers(EntityManagerInterface $em): array
    {
        return $em->getRepository(User::class)->findAll();
    }

    public function getPosts(EntityManagerInterface $em): array
    {
        return $em->getRepository(Post::class)->findAll();
    }

    public function getPostsByDay(EntityManagerInterface $em, String $day, User $user)
    {
        return $em->getRepository(Post::class)->findByDay('day', $day, $user);
    }
}
