<form action="">
    <label>Usuario</label>
    <input type="text" name="usuario"/>
    <label>Clave</label>
    <input type="password" name="clave"/>
    <input type="submit" name="accionusuarios" value="Acceder"/>
    <input type="submit" name="accionusuarios" value="Registrarme"/>
</form>
