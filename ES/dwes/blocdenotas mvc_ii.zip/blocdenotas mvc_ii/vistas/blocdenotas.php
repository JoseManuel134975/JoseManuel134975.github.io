<form action="">
    <input type="submit" value="Cerrar sesión" name="accionusuarios"/>
</form>
<form action="">
    <div>
        <textarea rows="10" cols="120" name="contenido"><?php echo $contenido; ?></textarea>
    </div>
    <label>Fichero</label>
    <input type="text" name="nombre_fichero" value="<?php echo $nombre_fichero; ?>" />
    <input type="submit" value="Abrir" name="accionbloc"/>
    <input type="submit" value="Guardar" name="accionbloc"/>
    <input type="submit" value="Imprimir en pdf" name="accionbloc"/>
    <input type="submit" value="Explorar" name="accionbloc"/>
    <input type="submit" value="Copiar" name="accionbloc"/>
    <input type="submit" value="Descargar" name="accionbloc"/>
    <input type="submit" value="Subir fichero" name="accionbloc"/>
    
<form>
