<h4>
    <?php if (isset($mensaje)) echo $mensaje; ?>
</h4>