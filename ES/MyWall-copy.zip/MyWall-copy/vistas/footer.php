<html>

<body>
    <footer>
        <p>&copy; Desarrollado por José Manuel</p>
    </footer>
</body>

</html>