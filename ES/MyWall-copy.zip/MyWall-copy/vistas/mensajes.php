<html>

<body>
    <h4 id="mensaje">
        <?php if (isset($mensaje)) echo $mensaje; ?>
    </h4>
</body>

</html>