<html>

<body>
    <nav>
        <ul>
            <li><a href="./muro.php">Mi muro</a></li>
        </ul>
        <form action="">
            <input id="cerrarSesion" type="submit" name="accionusuarios" value="Cerrar sesion">
        </form>
    </nav>
</body>

</html>