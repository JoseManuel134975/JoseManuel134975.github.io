<html>

<body>
    <form id="login" action="">
        <label for="nombre">Usuario: </label><br>
        <input type="text" name="usuario" id="nombre"><br>
        <label for="contrasena">Contraseña: </label><br>
        <input type="password" name="clave" id="contrasena"><br>
        <input type="submit" name="accionusuarios" value="Acceder"><br>
        <input type="submit" name="accionusuarios" value="Registrarme">
    </form>
</body>

</html>